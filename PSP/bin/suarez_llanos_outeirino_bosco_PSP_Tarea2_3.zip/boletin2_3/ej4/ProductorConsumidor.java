package boletin2_3.ej4;

import java.util.concurrent.Semaphore;

public class ProductorConsumidor extends Thread {
	
	static int n=0;
	private final int MAX=20;
	Semaphore s;
	boolean op;
	
	public ProductorConsumidor(boolean op) {
		this.op=op;
		s=new Semaphore(2);
	}
	
	public synchronized void productor() throws InterruptedException {
		if(n==20) {
			s.acquire(1);
		}
		
		System.out.println("produce: "+(++n));
		
		if(n==1) {
			s.release(2);
		}
	}
	
	public synchronized void consumidor() throws InterruptedException {
		if(n==0) {
			s.acquire(2);
		}
		
		System.out.println("consume: "+(--n));
		
		if(n==19) {
			s.release(1);
		}
	}
	
	@Override
	public void run() {
		if(op) {
			for (int i = 0; i < 20; i++)
				try {
					productor();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
		}else
			for (int i = 0; i < 20; i++)
				try {
					consumidor();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		
	}
}
