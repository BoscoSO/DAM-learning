package boletin2_3.ej4;

public class Ejercicio4 {

	
	public static void main(String[] args) {
		Thread t1=new ProductorConsumidor(true);
		Thread t2=new ProductorConsumidor(false);
		
		t1.start();
		t2.start();
	}
}
